<?php
/*
Plugin Name: Beats Upload Player
Plugin URI: https://www.crystalthedeveloper.ca
Description: Upload and manage beats, with a visual player.
Version: 1.0.0
Author: Crystal The Developer Inc.
Author URI: https://www.crystalthedeveloper.ca
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: beats-upload-player
*/

/**
 * Bootstrap file that registers every component (shortcodes, AJAX handlers,
 * admin pages) and wires shared helpers so beats can be uploaded, listed,
 * and played from the front-end experience.
 */

if (!defined('ABSPATH')) exit;

if (!defined('BEATS_UPLOAD_PLAYER_VERSION')) {
  define('BEATS_UPLOAD_PLAYER_VERSION', '1.5.0');
}

// === Includes ===
require_once plugin_dir_path(__FILE__) . 'includes/beats-categories.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-functions.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-ajax.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-shortcodes.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-manager.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-category-search.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-visualizer.php';

// Ensure storage directories/files exist early.
add_action('plugins_loaded', 'beats_prepare_storage', 5);
add_action('init', 'beats_prepare_storage', 1);
register_activation_hook(__FILE__, 'beats_prepare_storage');

add_action('plugins_loaded', 'beats_prime_data', 20);

function beats_force_loader_enqueue() {
  if (wp_script_is('beats-loader', 'enqueued')) {
    return;
  }
  wp_enqueue_script('beats-loader');
  error_log('Beats Debug: forced enqueue of beats-loader.js');
}
add_action('wp_footer', 'beats_force_loader_enqueue', 1);

// === Public Assets ===
function beats_register_public_assets() {
  $dir = plugin_dir_url(__FILE__);
  $version = BEATS_UPLOAD_PLAYER_VERSION;

  wp_register_style('beats-upload-style', $dir . 'public/css/beats-upload.css', [], $version);
  wp_register_style('beats-category-search-style', $dir . 'public/css/beats-category-search.css', [], $version);
  wp_register_style('beats-visualizer-style', $dir . 'public/css/beats-visualizer.css', [], $version);

  wp_register_script('beats-loader', $dir . 'public/js/beats-loader.js', [], $version, true);
  wp_register_script('beats-player', $dir . 'public/js/beats-player.js', [], $version, true);
  wp_register_script('beats-visualizer', $dir . 'public/js/beats-visualizer.js', [], $version, true);
  wp_add_inline_script('beats-visualizer', "
    (function() {
      function startVisualizer() {
        if (typeof BeatsVisualizerInit === 'function') {
          BeatsVisualizerInit();
        }
      }
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startVisualizer);
      } else {
        startVisualizer();
      }
    })();
  ", 'after');

  wp_localize_script('beats-loader', 'beats_ajax', [
    'ajax_url' => admin_url('admin-ajax.php'),
    'nonce'    => wp_create_nonce('beats-load'),
  ]);
}
add_action('wp_enqueue_scripts', 'beats_register_public_assets');

// === Admin Assets ===
function beats_enqueue_admin_assets($hook) {
  $valid_hooks = [
    'toplevel_page_beats-manager',
    'beats-manager_page_beats-manager-upload',
    'beats-manager_page_beats-manager-library',
    'beats-manager_page_beats-manager-visualizer',
  ];

  if (!in_array($hook, $valid_hooks, true)) {
    return;
  }

  $dir = plugin_dir_url(__FILE__);
  $paths = beats_paths();

  wp_enqueue_style('beats-admin-style', $dir . 'admin/css/admin.css', [], BEATS_UPLOAD_PLAYER_VERSION);
  wp_enqueue_script('beats-admin-script', $dir . 'admin/js/admin.js', ['jquery'], BEATS_UPLOAD_PLAYER_VERSION, true);

  wp_localize_script('beats-admin-script', 'BeatsAdmin', [
    'ajax'       => admin_url('admin-ajax.php'),
    'nonce'      => wp_create_nonce('beats-admin'),
    'baseUrl'    => $paths['url'],
    'categories' => beats_get_categories(),
    'defaultArt' => $dir . 'public/images/default-art.webp',
    'uploadLink' => admin_url('admin.php?page=beats-manager#beats-admin-upload'),
  ]);
}
add_action('admin_enqueue_scripts', 'beats_enqueue_admin_assets');
