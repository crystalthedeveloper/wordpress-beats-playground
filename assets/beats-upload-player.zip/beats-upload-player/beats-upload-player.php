<?php
/*
Plugin Name: Beats Upload Player
Plugin URI: https://www.crystalthedeveloper.ca
Description: Upload and manage beats, with a visual player.
Version: 1.0.0
Author: Crystal The Developer Inc.
Author URI: https://www.crystalthedeveloper.ca
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: beats-upload-player
*/

/**
 * Bootstrap file that registers every component (shortcodes, AJAX handlers,
 * admin pages) and wires shared helpers so beats can be uploaded, listed,
 * and played from the front-end experience.
 */

if (!defined('ABSPATH')) exit;

if (!defined('BEATS_UPLOAD_PLAYER_VERSION')) {
  define('BEATS_UPLOAD_PLAYER_VERSION', '1.5.0');
}

// === Includes ===
require_once plugin_dir_path(__FILE__) . 'includes/beats-categories.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-functions.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-ajax.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-shortcodes.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-manager.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-category-search.php';
require_once plugin_dir_path(__FILE__) . 'includes/beats-visualizer.php';

// Ensure storage directories/files exist early.
add_action('plugins_loaded', 'beats_prepare_storage', 5);
add_action('init', 'beats_prepare_storage', 1);
register_activation_hook(__FILE__, 'beats_prepare_storage');

add_action('plugins_loaded', 'beats_prime_data', 20);

function beats_is_playground_env() {
  if (defined('WP_PLAYGROUND') && WP_PLAYGROUND) {
    return true;
  }
  if (defined('IS_PLAYGROUND') && IS_PLAYGROUND) {
    return true;
  }
  if (function_exists('wp_get_environment_type') && wp_get_environment_type() === 'playground') {
    return true;
  }
  return false;
}

function beats_get_demo_page_content() {
  return <<<'HTML'
<!-- wp:group {"tagName":"main","align":"full","style":{"spacing":{"padding":{"top":"30px","right":"20px","bottom":"40px","left":"20px"}}}} -->
<main class="wp-block-group alignfull" style="padding-top:30px;padding-right:20px;padding-bottom:40px;padding-left:20px">
<!-- wp:group {"align":"full","anchor":"beats-wrapper","style":{"spacing":{"blockGap":"18px","margin":{"top":"0","bottom":"0"},"padding":{"top":"24px","right":"24px","bottom":"24px","left":"24px"}},"border":{"radius":"16px","color":"#f1f1f1","width":"1px"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" id="beats-wrapper" style="border-color:#f1f1f1;border-width:1px;border-radius:16px;margin-top:0;margin-bottom:0;padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px">
<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Beats</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Preview every Beats shortcode below.</p>
<!-- /wp:paragraph -->
<!-- wp:group {"align":"full","style":{"spacing":{"blockGap":"16px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group alignfull" style="gap:16px">
<!-- wp:shortcode -->[beats_category_search]<!-- /wp:shortcode -->
<!-- wp:shortcode -->[beats_visualizer]<!-- /wp:shortcode -->
<!-- wp:shortcode -->[beats_display_home]<!-- /wp:shortcode -->
<!-- wp:shortcode -->[beats_global_player]<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</main>
<!-- /wp:group -->
HTML;
}

function beats_seed_demo_front_page() {
  static $seeded = false;
  if ($seeded || !beats_is_playground_env()) {
    return;
  }
  $seeded = true;

  $page_args = [
    'post_title'   => 'Beats Demo',
    'post_name'    => 'beats-demo',
    'post_status'  => 'publish',
    'post_type'    => 'page',
    'post_content' => beats_get_demo_page_content(),
    'post_author'  => get_current_user_id() ?: 1,
  ];

  $existing_page = get_page_by_path('beats-demo');
  if ($existing_page) {
    $page_args['ID'] = $existing_page->ID;
    $page_id = wp_update_post($page_args);
  } else {
    $page_id = wp_insert_post($page_args);
  }

  if (!is_wp_error($page_id)) {
    update_option('show_on_front', 'page');
    update_option('page_on_front', $page_id);
    update_option('page_for_posts', 0);
  }
}
register_activation_hook(__FILE__, 'beats_seed_demo_front_page');
add_action('init', 'beats_seed_demo_front_page', 25);

function beats_filter_show_on_front_option($value) {
  if (beats_is_playground_env()) {
    return 'page';
  }
  return $value;
}

function beats_filter_page_on_front_option($value) {
  if (!beats_is_playground_env()) {
    return $value;
  }
  $page = get_page_by_path('beats-demo');
  if ($page) {
    return $page->ID;
  }
  return $value;
}

function beats_filter_page_for_posts_option($value) {
  if (beats_is_playground_env()) {
    return 0;
  }
  return $value;
}

add_filter('option_show_on_front', 'beats_filter_show_on_front_option');
add_filter('option_page_on_front', 'beats_filter_page_on_front_option');
add_filter('option_page_for_posts', 'beats_filter_page_for_posts_option');

function beats_force_loader_enqueue() {
  if (wp_script_is('beats-loader', 'enqueued')) {
    return;
  }
  wp_enqueue_script('beats-loader');
}
add_action('wp_footer', 'beats_force_loader_enqueue', 1);

// === Public Assets ===
function beats_register_public_assets() {
  $dir = plugin_dir_url(__FILE__);
  $version = BEATS_UPLOAD_PLAYER_VERSION;

  wp_register_style('beats-upload-style', $dir . 'public/css/beats-upload.css', [], $version);
  wp_register_style('beats-category-search-style', $dir . 'public/css/beats-category-search.css', [], $version);
  wp_register_style('beats-visualizer-style', $dir . 'public/css/beats-visualizer.css', [], $version);

  wp_register_script('beats-loader', $dir . 'public/js/beats-loader.js', [], $version, true);
  wp_register_script('beats-player', $dir . 'public/js/beats-player.js', [], $version, true);
  wp_register_script('beats-visualizer', $dir . 'public/js/beats-visualizer.js', [], $version, true);
  wp_add_inline_script('beats-visualizer', "
    (function() {
      function startVisualizer() {
        if (typeof BeatsVisualizerInit === 'function') {
          BeatsVisualizerInit();
        }
      }
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startVisualizer);
      } else {
        startVisualizer();
      }
    })();
  ", 'after');

  wp_localize_script('beats-loader', 'beats_ajax', [
    'ajax_url' => admin_url('admin-ajax.php'),
    'nonce'    => wp_create_nonce('beats-load'),
  ]);
}
add_action('wp_enqueue_scripts', 'beats_register_public_assets');

// === Admin Assets ===
function beats_enqueue_admin_assets($hook) {
  $valid_hooks = [
    'toplevel_page_beats-manager',
    'beats-manager_page_beats-manager-upload',
    'beats-manager_page_beats-manager-library',
    'beats-manager_page_beats-manager-visualizer',
  ];

  if (!in_array($hook, $valid_hooks, true)) {
    return;
  }

  $dir = plugin_dir_url(__FILE__);
  $paths = beats_paths();

  wp_enqueue_style('beats-admin-style', $dir . 'admin/css/admin.css', [], BEATS_UPLOAD_PLAYER_VERSION);
  wp_enqueue_script('beats-admin-script', $dir . 'admin/js/admin.js', ['jquery'], BEATS_UPLOAD_PLAYER_VERSION, true);

  wp_localize_script('beats-admin-script', 'BeatsAdmin', [
    'ajax'       => admin_url('admin-ajax.php'),
    'nonce'      => wp_create_nonce('beats-admin'),
    'baseUrl'    => $paths['url'],
    'categories' => beats_get_categories(),
    'defaultArt' => $dir . 'public/images/default-art.webp',
    'uploadLink' => admin_url('admin.php?page=beats-manager#beats-admin-upload'),
  ]);
}
add_action('admin_enqueue_scripts', 'beats_enqueue_admin_assets');
