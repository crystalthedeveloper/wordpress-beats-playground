<?php
if (!defined('ABSPATH')) exit;

/**
 * Core utility helpers: file/path bootstrap, JSON persistence, demo seeding,
 * and grouping logic used by AJAX + shortcodes.
 */

/**
 * Paths, File Handling, JSON Helpers
 */
function beats_paths() {
  static $paths = null;
  if ($paths !== null) {
    return $paths;
  }

  $uploads = wp_upload_dir();
  $base  = trailingslashit($uploads['basedir']) . 'beats/';
  $url   = trailingslashit($uploads['baseurl']) . 'beats/';
  $audio = $base . 'audio/';
  $img   = $base . 'images/';

  $paths = [
    'base' => $base,
    'url' => $url,
    'audio_dir' => $audio,
    'img_dir' => $img,
    'json' => $base . 'beats.json'
  ];

  beats_ensure_storage_locations($paths);
  return $paths;
}

if (!function_exists('beats_ensure_storage_locations')) {
  function beats_ensure_storage_locations($paths) {
    $dirs = [$paths['base'], $paths['audio_dir'], $paths['img_dir']];
    foreach ($dirs as $dir) {
      if (!is_dir($dir)) {
        wp_mkdir_p($dir);
      }
      if (is_dir($dir) && !is_writable($dir)) {
        @chmod($dir, 0755);
      }
    }

    $json_dir = dirname($paths['json']);
    if (!is_dir($json_dir)) {
      wp_mkdir_p($json_dir);
    }
    if (!file_exists($paths['json'])) {
      @file_put_contents($paths['json'], json_encode([], JSON_PRETTY_PRINT));
    }
    if (file_exists($paths['json']) && !is_writable($paths['json'])) {
      @chmod($paths['json'], 0644);
    }
  }
}

if (!function_exists('beats_prepare_storage')) {
  function beats_prepare_storage() {
    beats_paths(); // ensures directories/files exist.
  }
}

if (!function_exists('beats_prime_data')) {
  function beats_prime_data() {
    beats_paths();
    beats_seed_playground_demo();
    beats_read_json();
    beats_get_categories();
  }
}

add_filter('the_content', 'do_shortcode', 11);
add_filter('render_block', function ($content, $block) {
  if (empty($block['blockName']) || $block['blockName'] !== 'core/shortcode') {
    return $content;
  }

  if (!empty($block['attrs']['text'])) {
    return shortcode_unautop(do_shortcode($block['attrs']['text']));
  }
  if (!empty($block['innerContent'])) {
    return shortcode_unautop(do_shortcode(implode('', $block['innerContent'])));
  }
  if (!empty($block['innerHTML'])) {
    return shortcode_unautop(do_shortcode($block['innerHTML']));
  }

  return shortcode_unautop(do_shortcode($content));
}, 10, 2);

function beats_is_playground() {
  static $flag = null;
  if ($flag !== null) {
    return $flag;
  }

  $flag = (
    (defined('IS_PLAYGROUND') && IS_PLAYGROUND) ||
    (defined('WP_PLAYGROUND') && WP_PLAYGROUND) ||
    (defined('WP_ENVIRONMENT_TYPE') && WP_ENVIRONMENT_TYPE === 'playground')
  );

  return $flag;
}

function beats_seed_playground_demo() {
  if (!beats_is_playground()) {
    return;
  }

  $paths = beats_paths();
  $json_file = $paths['json'];
  $existing = [];
  if (file_exists($json_file)) {
    $existing = json_decode(@file_get_contents($json_file), true);
    if (is_array($existing) && !empty($existing)) {
      return;
    }
  }

  $seed_file = plugin_dir_path(__FILE__) . '../resources/demo/beats-playground.json';
  if (!file_exists($seed_file)) {
    return;
  }

  $seed = json_decode(file_get_contents($seed_file), true);
  if (!is_array($seed) || empty($seed)) {
    return;
  }

  $demo_dir = plugin_dir_path(__FILE__) . '../resources/demo/';

  $assets = [];
  foreach ($seed as $beat) {
    if (!empty($beat['file'])) {
      $assets[] = $beat['file'];
    }
    if (!empty($beat['image'])) {
      $assets[] = $beat['image'];
    }
  }

  $assets = array_unique(array_filter($assets));
  foreach ($assets as $asset) {
    $relative = ltrim($asset, '/');
    $target = $paths['base'] . $relative;
    $target_dir = dirname($target);
    if (!is_dir($target_dir)) {
      wp_mkdir_p($target_dir);
    }
    if (file_exists($target)) {
      continue;
    }
    $source = $demo_dir . basename($relative);
    if (file_exists($source)) {
      @copy($source, $target);
    }
  }

  beats_write_json($seed);
}

function beats_read_json() {
  $p = beats_paths();
  $f = $p['json'];
  if (!file_exists($f)) {
    beats_ensure_storage_locations($p);
  }
  $contents = @file_get_contents($f);
  if ($contents === false) {
    // Attempt to recreate the file if it was removed mid-request.
    beats_ensure_storage_locations($p);
    $contents = @file_get_contents($f);
    if ($contents === false) {
      return [];
    }
  }
  $data = json_decode($contents, true);
  if (!is_array($data)) {
    $data = [];
  }

  return $data;
}

function beats_write_json($data) {
  $p = beats_paths();
  beats_ensure_storage_locations($p);
  @file_put_contents($p['json'], json_encode(array_values($data), JSON_PRETTY_PRINT));
}

if (!function_exists('beats_grouped_categories_or_default')) {
  function beats_grouped_categories_or_default($grouped, $data) {
    if (!empty($grouped)) {
      return $grouped;
    }
    if (!empty($data)) {
      $grouped[__('Uncategorized', 'beats-upload-player')] = $data;
    }
    return $grouped;
  }
}

/**
 * Group beats by category for rendering.
 */
if (!function_exists('beats_group_beats_by_category')) {
  function beats_group_beats_by_category() {
    $data = beats_read_json();
    if (empty($data) || !is_array($data)) {
      return [];
    }

    $grouped = [];
    foreach ($data as $beat) {
      $category = isset($beat['category']) && $beat['category'] !== ''
        ? (string) $beat['category']
        : __('Uncategorized', 'beats-upload-player');
      $grouped[$category][] = $beat;
    }
    return beats_grouped_categories_or_default($grouped, $data);
  }
}

/**
 * Render a batch of categories into HTML shared by the shortcode + AJAX.
 */
if (!function_exists('beats_render_category_batch')) {
  function beats_render_category_batch($offset = 0, $limit = 4) {
    $limit = max(1, intval($limit));
    $offset = max(0, intval($offset));

    $grouped = beats_group_beats_by_category();
    $categories = array_keys($grouped);
    $total_categories = count($categories);

    if ($total_categories === 0) {
      return [
        'html' => '',
        'next_offset' => $offset,
        'has_more' => false,
        'total_categories' => 0,
      ];
    }

    $batch = array_slice($categories, $offset, $limit);
    if (empty($batch)) {
      return [
        'html' => '',
        'next_offset' => $offset,
        'has_more' => false,
        'total_categories' => $total_categories,
      ];
    }

    $paths = beats_paths();

    ob_start();
    foreach ($batch as $cat) {
      echo '<div class="beats-section" id="' . sanitize_title($cat) . '">';
      echo '<h4>' . esc_html($cat) . '</h4><div class="beats-row">';

      foreach ($grouped[$cat] as $b) {
        $url = esc_url($paths['url'] . ($b['file'] ?? ''));
        $img = !empty($b['image'])
          ? esc_url($paths['url'] . $b['image'])
          : plugin_dir_url(__FILE__) . '../public/images/default-art.webp';
        $producer = esc_html($b['producer'] ?? 'Unknown Producer');
        $price_raw = isset($b['price']) ? trim((string) $b['price']) : '';
        $price_value = $price_raw !== '' ? number_format((float) $price_raw, 2, '.', '') : '';
        $price_display = $price_value !== '' ? 'CAD $' . $price_value : '';

        echo '<div class="beat-card"
                data-src="' . $url . '"
                data-name="' . esc_attr($b['name'] ?? '') . '"
                data-producer="' . esc_attr($producer) . '"
                data-cat="' . esc_attr($b['category'] ?? '') . '"
                data-price="' . esc_attr($price_display !== '' ? $price_display : 'Free') . '"
                data-img="' . $img . '">';
        echo '<div class="beat-thumb">';
        echo '<img src="' . $img . '" alt="Beat Cover" loading="lazy">';
        echo '<div class="beat-title-ribbon">' . esc_html($b['name'] ?? '') . '</div>';
        echo '<div class="beat-overlay">';
        echo '<div class="beat-overlay-actions">';
        echo '<button type="button" class="beat-info-btn" aria-label="Show beat info">&#9432;</button>';
        echo '<button type="button" class="beat-cart-btn" aria-label="Show price">&#128722;</button>';
        echo '<button type="button" class="beat-play-btn" aria-label="Play beat">▶</button>';
        echo '</div>';
        echo '<div class="beat-overlay-panel">';
        echo '<div class="beat-panel beat-panel-info"><small class="beat-producer">By ' . $producer . '</small></div>';
        if ($price_display) {
          echo '<div class="beat-panel beat-panel-cart">';
          echo '<span class="beat-price">' . esc_html($price_display) . '</span>';
          echo '<a class="beat-store-btn" href="https://www.crystalthedeveloper.ca/store" target="_blank" rel="noopener noreferrer">Buy Now</a>';
          echo '</div>';
        } else {
          echo '<div class="beat-panel beat-panel-cart beat-panel-cart--empty">';
          echo '<span class="beat-price">Free</span>';
          echo '</div>';
        }
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
      }

      echo '</div></div>';
    }

    $html = ob_get_clean();
    $next_offset = $offset + count($batch);
    $has_more = $next_offset < $total_categories;

    return [
      'html' => $html,
      'next_offset' => $next_offset,
      'has_more' => $has_more,
      'total_categories' => $total_categories,
    ];
  }
}
