<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('beats_visualizer_option_key')) {
  function beats_visualizer_option_key() {
    return 'beats_visualizer_enabled';
  }
}

if (!function_exists('beats_visualizer_bootstrap_option')) {
  function beats_visualizer_bootstrap_option() {
    $key = beats_visualizer_option_key();
    if (get_option($key, '__missing__') === '__missing__') {
      add_option($key, '1');
    }
  }
  beats_visualizer_bootstrap_option();
}

if (!function_exists('beats_visualizer_is_enabled')) {
  function beats_visualizer_is_enabled() {
    return get_option(beats_visualizer_option_key(), '0') === '1';
  }
}

if (!function_exists('beats_visualizer_enqueue_assets')) {
  function beats_visualizer_enqueue_assets() {
    if (!beats_visualizer_is_enabled()) {
      return;
    }
    wp_enqueue_style('beats-visualizer-style');
    wp_enqueue_script('beats-visualizer');
  }
}

if (!function_exists('beats_visualizer_shortcode')) {
  function beats_visualizer_shortcode() {
    if (!beats_visualizer_is_enabled()) {
      return '<p class="beats-visualizer-disabled">' . esc_html__('Visualizer is disabled in Beats Manager.', 'beats-upload-player') . '</p>';
    }

    beats_visualizer_enqueue_assets();

    return '
      <div id="beats-visualizer-container">
        <canvas id="beats-canvas"></canvas>
      </div>
    ';
  }
  add_shortcode('beats_visualizer', 'beats_visualizer_shortcode');
}

if (!function_exists('beats_visualizer_demo_shortcode')) {
  function beats_visualizer_demo_shortcode() {
    if (!beats_visualizer_is_enabled()) {
      return '<p class="beats-visualizer-disabled">' . esc_html__('Visualizer demo is disabled. Enable it from Beats Manager.', 'beats-upload-player') . '</p>';
    }

    beats_visualizer_enqueue_assets();

    $heading = '<h3 class="beats-visualizer-demo__heading">' . esc_html__('Beats Visualizer Demo', 'beats-upload-player') . '</h3>';

    return '
      <div class="beats-visualizer-demo">
        ' . $heading . '
        ' . beats_visualizer_shortcode() . '
      </div>
    ';
  }
  add_shortcode('beats_visualizer_demo', 'beats_visualizer_demo_shortcode');
}
