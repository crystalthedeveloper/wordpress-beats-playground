<?php
return array(
    'dependencies' => array( 'wp-blocks', 'wp-element', 'wp-i18n' ),
    'version'      => BEATS_UPLOAD_PLAYER_VERSION,
);
